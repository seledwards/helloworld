#!/usr/bin/env bash
touch /local/myspecialfile